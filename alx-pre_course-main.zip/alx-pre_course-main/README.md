 alx-pre_course 

I'm now a ALX Student 

# This is my first github repository in my ALX software engineering journey and as a full-stack engineer 
